
<html>

    <h1>This is a support page</h1>
    <div><h2>${message}</h2></div>
    
    <h3>Your Car will get ready shortly</h3>

</html>