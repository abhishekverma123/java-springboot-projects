<html>

  <a href = "/support?id=${id}"> Contact Support</a>  
    
    
    
</html>